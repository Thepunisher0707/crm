<?php
session_start();

session_destroy();
header("Location:index.html");
//echo "window.open("dashboard.php")";
?>