<?php
$userserach=$_POST['userserach'];


require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from customer_master  where cust_name like '$userserach%' ");
	$row_count=mysqli_num_rows($result);
	echo "<table border='1'>";
	  if($row_count!=0)
	{
	while($row = mysqli_fetch_assoc($result)) {
	echo "<tr><td>".$row['cust_name']."</td><td>".$row['cust_mobile_no']."</td><td>".$row['cust_email']."</td><td>".$row['cust_password']."</td> 

	<td><input type='button' onclick='deletecust(".$row['cust_id'].");' value='Delete Customer' ></td>

	<td><a href='update_cust.php?cust_id=".$row['cust_id']."'>
	<input type='button'  value='Edit' ></a></td> </tr>";
	}
    }
	
?>