<?php
$cust_name=$_POST['cust_name'];
$product_qua=$_POST['product_qua'];
$product_name=$_POST['product_name'];
$product_price=$_POST['product_price'];


require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
//echo "insert into order (cust_name,product_name,product_price) 	values('$cust_name','$product_name','$product_price')"

$result = mysqli_query($con,"insert into order_master (cust_name,product_qua,product_name,product_price)
		values('$cust_name','$product_qua','$product_name','$product_price')");
	
	
	$custid=mysqli_insert_id($con);
	if($custid>0)
	{
	echo 'Product BUY Successfully';
	}
	

?>