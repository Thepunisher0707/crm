<html>
<head>
 <script src="js/jquery-3.2.1.min.js"></script>
<script>
function totatalusers(type){
  $.post("productl.php",
    { 	
	 type:type
	},
    function(data,status){
	if(type=='CUSTOMERS')
		document.getElementById('totatalusers').innerHTML = data;
	else
		document.getElementById('totatalcustomers').innerHTML = data;
	  
	});

	}
	
</script>
</head>
<center>
<body onload="totatalusers('USERS');totatalusers('CUSTOMERS');"
 style="background-color:white" >
<h1> Dash Board </h1>
<br>

<table border="1">
<tr>
<td>
<b>Saller Name </b>
</td>
<td>
<b>Product Name </b>
</td>
<td>
<b> Product Price </b>
</td>
</tr>
<tr>
<td align = "center">
<span id="totatalusers"></span>
</td>
<td align = "center">
<span id="totatalcustomers"></span>
</td>
</tr>
</table>
<br>
<br>
           <br>
           

</body>
</center>
</html>
