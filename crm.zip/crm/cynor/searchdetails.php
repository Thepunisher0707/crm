<?php
$userserach=$_POST['userserach'];


require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from user_master  where user_name like '$userserach%' ");
	$row_count=mysqli_num_rows($result);
	echo "<table border='1'>";
	  if($row_count!=0)
	{
	while($row = mysqli_fetch_assoc($result)) {
	echo "<tr><td>".$row['user_name']."</td><td>".$row['mobile']."</td><td>".$row['email']."</td><td>".$row['password']."</td>  
	
	<td><input type='button' onclick='deleteuser(".$row['user_id'].");' value='Delete' ></td>
	
	<td><a href='update_user.php?user_id=".$row['user_id']."'>
	<input type='button'  value='Edit' ></a></td> </tr>";
	}
    }
	
?>