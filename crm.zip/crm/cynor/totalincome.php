<?php
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$type=$_POST['type'];
if($type=='INCOME')
{
$result =  mysqli_query($con,"select sum(product_price*product_qua) as usercount from order_master");
	$row_count=mysqli_num_rows($result);
	$row=mysqli_fetch_assoc($result);
   if($row_count!=0)
	echo $row['usercount'];
	else 
	echo '0';
}
else 
{
$result =  mysqli_query($con,"select count(product_price*product_qua ) as customercount from customer_master");
	$row_count=mysqli_num_rows($result);
	$row=mysqli_fetch_assoc($result);
   if($row_count!=0)
	echo $row['customercount'];
	else 
	echo '0';	
}

?>