<?php
$userserach=$_POST['userserach'];


require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from product_master  where product_name like '$userserach%' ");
	$row_count=mysqli_num_rows($result);
	echo "<table border='1'>";
	  if($row_count!=0)
	{
	while($row = mysqli_fetch_assoc($result)) {
	echo "<tr>
	<td>".$row['product_seller']."</td>
	<td>".$row['product_name']."</td>
	<td>".$row['product_price']."</td>
	<td>".$row['product_details']."</td>  
	

	<td><input type='button' onclick='deleteproduct(".$row['product_id'].");' value='Delete Product' ></td>
	
	<td> <a href='buy_product.php?product_id=".$row['product_id']."'>
	<input type='button'  value='BUY Product' ></a></td> </tr>";
	}
    }
	
?>