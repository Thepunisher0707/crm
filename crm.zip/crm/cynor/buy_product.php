<?php
$product_id= $_GET['product_id'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from product_master  where product_id = '$product_id%' ");
$row = mysqli_fetch_assoc($result);
	
?>
<html>
<head>
<title> BUY PRODUCT </title>
 <script src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
function saveuser()
{
$.post("insertorder.php",
    {
	cust_name:$('#cust_name').val(),
	product_qua:$('#product_qua').val(),
	product_name:$('#product_name').val(),
	product_price:$('#product_price').val()
	},
	function(data,status){
	alert(data);
    });
}
function da()
{
	window.open("product_list.html")
}
function dada()
{
	window.open("dashboard.php")
}
//document.getElementById('getadvancesearchspan').innerHTML = data;

</script>
</head>

<input type="button" value="Go To Dashboard" onclick="dada()">
<center>
	<br>
	<br>
	<br>
	<body background="img/ul.jpg">

	<br>
	<br>
	<br>

		<h1> BUY PRODUCT </h1>
		<br>
		
		<table>
		<tr>
		<td> 
			<b>PRODUCT NAME</b>
		
		</td>
		<td>
		<input type="text" name="product_name" id="product_name" value="<?php echo $row['product_name'];?>" >
		</td>
		</tr>
		<tr>
		<td>
		<b>PRODUCT DETAILS</b>
		
		</td>
		<td>
		<input type="text"  name="product_details" id="product_details" value="<?php echo $row['product_details'];?>" >
		</td>
		</tr>
		<tr>
		<td>
			<b>PRODUCT PRICE<b/>
		
		</td>
		<td>
		<input type="text" name="product_price" id="product_price" value="<?php echo $row['product_price'];?>">
		</td>
		</tr>

		<tr>
		<td>
			<b>SELECT QUANTITY</b>
		
		</td>
		<td>

		<select id="product_qua" name="product_qua">
    <option value="1">1</option>
    <option value="2">2</option>
    <option value="3">3</option>
    <option value="4">4</option>
    <option value="5">5</option>
    <option value="6">6</option>
    <option value="7">7</option>
    <option value="8">8</option>
    <option value="9">9</option>
    <option value="10">10</option>
    
    
</select>

		</td>
		</tr>

		<tr>
		<td>
			<b>PAYMENT TYPE</b>
		
		</td>
		<td>
		<select name="Qua">
        <option>
            ONLINE BANKING
        </option>
        <option>
            DEBIT/CREDIT CARDS
        </option>
        <option>
            CASH ON DELIVERY
        </option>
        <option>
            EMI
        </option>
        
    </select>
		</td>
		</tr>

		<tr>
		<td>
			<b>Customer</b>
		
		</td>
		<td>
		<select name="cust_name" id="cust_name">
		<?php 
		require_once 'config.php';        
		$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
        $result =  mysqli_query($con,"select * from customer_master order by cust_name asc ");
	while($row = mysqli_fetch_assoc($result)) {
	echo '<option value="'.$row['cust_name'].'">'.$row['cust_name'].'</option>';
	
	}
    
	?>
        
    </select>
		</td>
		</tr>
	
		
		<tr>
		<td colspan="2">
		
			<br>
			
		
		<input type="button" value="PROCCED TO CONTUNE" height="30" width="90" name="sign" onclick="saveuser()">
		</td>
		</tr>
		</body>
</center>
</html>
