<?php
$cust_id=$_POST['cust_id'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"delete from customer_master  where cust_id = '$cust_id' ");
echo 'Customer sucessfully Deleted!!';	
?>