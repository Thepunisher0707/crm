<?php
$product_id=$_POST['product_id'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"delete from product_master  where product_id = '$product_id' ");
echo 'Product sucessfully Deleted!!';	
?>