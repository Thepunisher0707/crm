<?php
$user_name=$_POST['user_name'];
$mobile=$_POST['mobile'];
$email=$_POST['email'];
$password=$_POST['password'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from user_master  where mobile ='$mobile'");
	$row_count=mysqli_num_rows($result);
   if($row_count!=0)
	{
	echo 'User is already registered ';
	}
    else
	{
	$result = mysqli_query($con,"insert into user_master (user_name,mobile,email,password)	values('$user_name','$mobile','$email','$password')");
	"insert into user_master (user_name,mobile,email,password)	values('$user_name','$mobile','$email','$password')";
	$userid=mysqli_insert_id($con);
	if($userid>0)
	{
	echo 'Thanks for Registration.';
	}
	}
?>