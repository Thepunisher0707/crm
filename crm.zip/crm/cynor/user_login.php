<?php

$mobile=$_POST['mobile'];

$password=$_POST['password'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from user_master   where mobile ='$mobile' and password = '$password'");
	$row_count=mysqli_num_rows($result);
	$row = mysqli_fetch_assoc($result);
   if($row_count!=0)
	{
		session_start();
		$_SESSION['user_id']= $row['user_id'];
		$_SESSION['mobile']= $row['mobile'];
		$_SESSION['user_name']= $row['user_name'];

	echo "1";
	}
    else
	{
		echo 'User or password not valid  ';
	}
?>