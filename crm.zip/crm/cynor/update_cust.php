<?php
$cust_id= $_GET['cust_id'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from customer_master  where cust_id = '$cust_id%' ");
$row = mysqli_fetch_assoc($result);
	
?>
<html>
<head>
<title> update Customer </title>
 <script src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
function saveuser(cust_id)
{
$.post("editcust.php",
    {
	cust_name:$('#cust_name').val(),
	cust_mobile_no:$('#cust_mobile_no').val(),
	cust_id:cust_id,
	cust_password:$('#cust_password').val() 	
	},
	function(data,status){
	alert(data);
    });
}
//document.getElementById('getadvancesearchspan').innerHTML = data;

</script>
</head>
<center>
	<br>
	<br>
	<br>
	<br>
	<br>
	<br>
	<body background="img/ul.jpg">

		<h1> UPDATE CUSTOMER </h1>
		
		<table>
		<tr>
		<td> 
		Name
		</td>
		<td>
		<input type="text" name="cust_name" id="cust_name" value="<?php echo $row['cust_name'];?>" >
		</td>
		</tr>
		<tr>
		<td>
		Mobile
		</td>
		<td>
		<input type="text" name="cust_mobile_no" id="cust_mobile_no" value="<?php echo $row['cust_mobile_no'];?>" >
		</td>
		</tr>
		<tr>
		<td>
		Password
		</td>
		<td>
		<input type="date" name="cust_password" id="cust_password" value="<?php echo $row['cust_password'];?>">
		</td>
		</tr>
		
		<tr>
		<td colspan="2">
		
			<br>
			
		
		<input type="button" value="UPDATE DEATILS" height="30" width="90" name="sign" onclick="saveuser('<?php echo $row['cust_id'];?>')">
		</td>
		</tr>
		</body>
</center>
</html>