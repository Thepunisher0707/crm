<?php
$product_id=$_POST['product_id'];
$product_name=$_POST['product_name'];
$product_details=$_POST['product_details'];
$product_price=$_POST['product_price'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from customer_master  where product_details ='$product_details'");
	$row_count=mysqli_num_rows($result);
   if($row_count!=0)
	{
	echo 'User is already registered ';
	}
    else
	{
	$result = mysqli_query($con,"insert into customer_master (cust_name,product_name,product_price,cust_address,cust_mobile)	values('$cust_name','$product_name','$product_price','$cust_address','$cust_mobile)");
	"insert into user_master (cust_name,product_price,product_price,cust_address,cust_mobile)	values('$cust_name','$product_name','$product_price','$cust_address','$cust_mobile')";
	$userid=mysqli_insert_id($con);
	if($userid>0)
	{
	echo 'Thanks for Registration.';
	}
	}
?>	
?>