<!DOCTYPE html>
<html lang="en">
<head>
<script src="js/jquery-3.2.1.min.js"></script>
<script>
   function searchdetails()
			{
			$.post("productl.php",
				{
				userserach:$('#userserach').val()
				},
				function(data,status){
				document.getElementById('searchdetail').innerHTML = data;
				});
			}
			
			function deleteuser(user_id)
			{
			$.post("deleteuser.php",
				{
				user_id:user_id
				},
				function(data,status){
				alert(data);
				searchdetails();
				});
			}

</script>
<script src="js/jquery-3.2.1.min.js"></script>


    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <title>CRM SYSTEM</title>
    <link rel="stylesheet" href="assets/vendors/mdi/css/materialdesignicons.min.css" />
    <link rel="stylesheet" href="assets/vendors/flag-icon-css/css/flag-icon.min.css" />
    <link rel="stylesheet" href="assets/vendors/css/vendor.bundle.base.css" />
    <link rel="stylesheet" href="assets/vendors/font-awesome/css/font-awesome.min.css" />
    <link rel="stylesheet" href="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css" />
    <link rel="stylesheet" href="assets/css/style.css" />
    <link rel="shortcut icon" href="img/cynor.png" />
	<style>
	html {
    font-family: Public Sans,sans-serif,-apple-system,blinkmacsystemfont,Segoe UI,roboto,Helvetica Neue,arial,sans-serif,"Apple Color Emoji","Segoe UI Emoji",Segoe UI Symbol;
    line-height: 1.5;
    font-size: 1rem;
    overflow-x: hidden;
    text-rendering: optimizeLegibility;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    -webkit-tap-highlight-color: rgba(0,0,0,0);
}

.navbar {
    padding-left: 25px;
    padding-right: 13px;
    background: #ffab2d;
    padding-bottom: 0;
    padding-top: 0;
}
.navbar .navbar-menu-wrapper {
    transition: width 0.25s ease;
    -webkit-transition: width 0.25s ease;
    -moz-transition: width 0.25s ease;
    -ms-transition: width 0.25s ease;
    color: #8e94a9;
    padding-left: 15px;
    padding-right: 15px;
    width: calc(100% - 260px);
    height: 70px;
    background: #ffab2d;
}

</style>
  </head>
  <body  onload="searchdetails();">
    <div class="container-scroller">
      <nav class="sidebar sidebar-offcanvas" id="sidebar">
        <div class="text-center sidebar-brand-wrapper d-flex align-items-center">
          <a class="sidebar-brand brand-logo" href="index.html"><img src="img/cynor.png" alt="logo" /></a>
          <a class="sidebar-brand brand-logo-mini pl-4 pt-3" href="index.html">
            <img src="img/cynor.png" alt="logo" /></a>
        </div>
        <ul class="nav">
          <li class="nav-item nav-profile">
            <a href="#" class="nav-link">
              <div class="nav-profile-image">
                <img src="assets/images/faces/face1.jpg" alt="profile" />
                <span class="login-status online"></span>
              </div>
              <div class="nav-profile-text d-flex flex-column pr-3">
                <span class="font-weight-medium mb-2">Sarthak Gadakh</span>
              </div>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="dashboard.php">
              <i class="mdi mdi-home menu-icon"></i>
              <span class="menu-title">Dashboard</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="userlist_new.php">
              <i class="mdi mdi-contacts menu-icon"></i>
              <span class="menu-title">User List</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="usermgmt_new.php">
              <i class="mdi mdi-contacts menu-icon"></i>
              <span class="menu-title">Add New User</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="custlist_new.php">
              <i class="mdi mdi-contacts menu-icon"></i>
              <span class="menu-title">Customer List</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="custmgmt_new.php">
              <i class="mdi mdi-contacts menu-icon"></i>
              <span class="menu-title">Add New Customer</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="productmaster_new.php">
              <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              <span class="menu-title">Add Product</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="productlist_new.php">
              <i class="mdi mdi-chart-bar menu-icon"></i>
              <span class="menu-title">Product List</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="orderlist_new.php">
              <i class="mdi mdi-table-large menu-icon"></i>
              <span class="menu-title">Order List</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="index.html">
              <i class="mdi mdi-contacts menu-icon"></i>
              <span class="menu-title">Sign Out</span>
            </a>
          </li>
          <br>
          <li class="nav-item">
            <a class="nav-link" href="https://www.bootstrapdash.com/demo/breeze-free/documentation/documentation.html">
            </a>
          </li>
          <li class="nav-item sidebar-actions">
            <div class="nav-link">
              <div class="mt-4">
                <div class="border-none">
                <a class="nav-link" href="">
                </div>
                <ul class="mt-4 pl-0">
                </ul>
              </div>
            </div>
          </li>
        </ul>
      </nav>
      <div class="container-fluid page-body-wrapper">
        <nav class="navbar col-lg-12 col-12 p-lg-0 fixed-top d-flex flex-row">
          <div class="navbar-menu-wrapper d-flex align-items-stretch justify-content-betwee">
            <a class="navbar-brand brand-logo-mini align-self-center d-lg-none" href="index.html">
              </a>
            </button>
          </div>
        </nav>
        <div class="main-panel">
          <div class="content-wrapper pb-0">
            <div class="page-header flex-wrap">
            
             
            </div>
            <div class="row">
              <div class="col-xl-12 col-lg-12 stretch-card grid-margin">

              <title> New User </title>
 <script src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
	
function saveuser()
{
$.post("insertuser.php",
    {
	user_name:$('#user_name').val(),
	mobile:$('#mobile').val(),
	email:$('#email').val(),
	password:$('#password').val() 	
	},
	function(data,status){
	alert(data);
    });
}
function logi()
{
	window.open("index.html")
}
//document.getElementById('getadvancesearchspan').innerHTML = data;

</script>




		<br>
		<br>
		<table>
        <tr>
            
		<tr>
            <td>
            <h2> Add New User</h2>
            </td>
        </tr>
        <br>
		<td> 
			<b>User Name</b>
		</td>
		<td>
		<input type="text" name="user_name" id="user_name" >
		</td>
		</tr>
		<tr>
		<td>
			<b>Mobile</b>
		</td>
		<td>
		<input type="number" name="mobile" id="mobile" maxlength="10" >
		</td>
		</tr>
		<tr>
		<td>
			<b>Email</b>
		</td>
		<td>
		<input type="text" name="email" id="email">
		</td>
		</tr>
		<tr>
		<td>
			<b>Password</b>
		</td>
		<td>
		<input type="password" name="password" id="password">
		</td>
		</tr>
		<tr>
		<td colspan="2">
			<h5>Alraedy have account?,Click On Login now</h5> 
		<input type="button" value=" Login Now " onclick="logi()">
		<input type="button" value="Create Now" height="40" width="90" name="sign" onclick="saveuser()">
		</td>
		</tr>
</center>
		
 
 </head>



                  </div>
                  </div>
                </div>
              </div>
          <footer class="footer">
            <div class="d-sm-flex justify-content-center justify-content-sm-between">
                
            </div>
          </footer>
        </div>
      </div>
    </div>
    <script src="assets/vendors/js/vendor.bundle.base.js"></script>
    <script src="assets/vendors/chart.js/Chart.min.js"></script>
    <script src="assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <script src="assets/vendors/flot/jquery.flot.js"></script>
    <script src="assets/vendors/flot/jquery.flot.resize.js"></script>
    <script src="assets/vendors/flot/jquery.flot.categories.js"></script>
    <script src="assets/vendors/flot/jquery.flot.fillbetween.js"></script>
    <script src="assets/vendors/flot/jquery.flot.stack.js"></script>
    <script src="assets/vendors/flot/jquery.flot.pie.js"></script>
    <script src="assets/js/off-canvas.js"></script>
    <script src="assets/js/hoverable-collapse.js"></script>
    <script src="assets/js/misc.js"></script>
    <script src="assets/js/dashboard.js"></script>
  </body>
</html>

        