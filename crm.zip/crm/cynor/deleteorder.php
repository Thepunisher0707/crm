<?php
$order_id=$_POST['order_id'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"delete from order_master  where order_id = '$order_id' ");
echo 'order sucessfully Deleted!!';	
?>