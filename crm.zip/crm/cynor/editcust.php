<?php
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$cust_id= $_POST['cust_id'];
$cust_name=$_POST['cust_name'];
$cust_mobile_no=$_POST['cust_mobile_no'];
$cust_password=$_POST['cust_password'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
//"update user_master set user_name = '$user_name', mobile = '$mobile' password = '$password'  where user_id = '$user_id' ";
$result =  mysqli_query($con,"update customer_master set cust_name = '$cust_name', cust_mobile_no = '$cust_mobile_no', cust_password = '$cust_password'  where cust_id = '$cust_id' ");
echo 'Customer sucessfully Update!!';	
?>