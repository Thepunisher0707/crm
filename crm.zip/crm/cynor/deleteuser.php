<?php
$user_id=$_POST['user_id'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"delete from user_master  where user_id = '$user_id' ");
echo 'User sucessfully Deleted!!';	
?>