<?php
$product_seller=$_POST['product_seller'];
$product_name=$_POST['product_name'];
$product_price=$_POST['product_price'];
$product_qua=$_POST['product_qua'];
$product_details=$_POST['product_details'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from product_master  where product_name ='$product_name'");
	$row_count=mysqli_num_rows($result);
	if($row_count!=0)
	{
	echo 'PRODUCT ALREADY ADDED ';
	}
    else
	{
  
	$result = mysqli_query($con,"insert into product_master (product_seller,product_name,product_price,product_qua,product_details)
		values('$product_seller','$product_name','$product_price','$product_qua','$product_details')");
	
	$custid=mysqli_insert_id($con);
	if($custid>0)
	{
	echo 'Product Add Successfully';
	}
}
?>