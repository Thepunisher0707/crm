<?php
$user_id= $_GET['user_id'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from user_master  where user_id = '$user_id%' ");
$row = mysqli_fetch_assoc($result);
	
?>
<html>
<head>
<title> update User </title>
 <script src="js/jquery-3.2.1.min.js"></script>
<script type="text/javascript">
function saveuser(user_id)
{
$.post("edituser.php",
    {
	user_name:$('#user_name').val(),
	mobile:$('#mobile').val(),
	user_id:user_id,
	password:$('#password').val() 	
	},
	function(data,status){
	alert(data);
    });
}
function dv()
{
	window.open("userlist.html")
}
//document.getElementById('getadvancesearchspan').innerHTML = data;

</script>
</head>

<center>
	<br>
	<br>
	<br>
	<body background="img/ul.jpg">
	<br>
	<br>
	<br>

		<h1> UPDATE USER </h1>
		
		<table>
		<tr>
		<td> 
		Name
		</td>
		<td>
		<input type="text" name="user_name" id="user_name" value="<?php echo $row['user_name'];?>" >
		</td>
		</tr>
		<tr>
		<td>
		Mobile
		</td>
		<td>
		<input type="text" name="mobile" id="mobile" value="<?php echo $row['mobile'];?>" >
		</td>
		</tr>
		<tr>
		<td>
		Password
		</td>
		<td>
		<input type="text" name="password" id="password" value="<?php echo $row['password'];?>">
		</td>
		</tr>
		
		<tr>
		<td colspan="2">
		
			<br>
			
		
		<input type="button" value="UPDATE DEATILS" height="30" width="90" name="sign" onclick="saveuser('<?php echo $row['user_id'];?>')">
		</td>
		</tr>
		</body>
</center>
</html>
