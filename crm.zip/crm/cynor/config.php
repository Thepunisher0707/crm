<?php
$HOST = "localhost"; // If you don't know what your host is, it's safe to leave it localhost
$USERNAME = "root"; // Database name
$PASSWORD = ""; // Username
$DB = "crm_mgmt";
?>