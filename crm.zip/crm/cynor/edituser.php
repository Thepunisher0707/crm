<?php
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$user_id= $_POST['user_id'];
$user_name=$_POST['user_name'];
$mobile=$_POST['mobile'];
$password=$_POST['password'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
//"update user_master set user_name = '$user_name', mobile = '$mobile' password = '$password'  where user_id = '$user_id' ";
$result =  mysqli_query($con,"update user_master set user_name = '$user_name', mobile = '$mobile', password = '$password'  where user_id = '$user_id' ");
echo 'User sucessfully Update!!';	
?>