<?php
$cust_name=$_POST['cust_name'];
$cust_mobile_no=$_POST['cust_mobile_no'];
$cust_email=$_POST['cust_email'];
$cust_password=$_POST['cust_password'];
$cust_address=$_POST['cust_address'];
require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from customer_master  where cust_mobile_no ='$cust_mobile_no'");
	$row_count=mysqli_num_rows($result);
	if($row_count!=0)
	{
	echo 'User is already registered ';
	}
    else
	{
	$result = mysqli_query($con,"insert into customer_master (cust_name,cust_password,cust_mobile_no,cust_email,cust_address)
		values('$cust_name','$cust_password','$cust_mobile_no','$cust_email','$cust_address')");
	
	$custid=mysqli_insert_id($con);
	if($custid>0)
	{
	echo 'Thanks for Registration.';
	}
	}
?>