<?php
$userserach=$_POST['userserach'];


require_once 'config.php';        
$con = mysqli_connect($HOST,$USERNAME,$PASSWORD,$DB);
$result =  mysqli_query($con,"select * from order_master  where cust_name like '$userserach%' ");
	$row_count=mysqli_num_rows($result);
	echo "<table border='1'>";
	  if($row_count!=0)
	{
	while($row = mysqli_fetch_assoc($result)) {
	echo "<tr><td>".$row['cust_name']."</td><td>".$row['product_name']."</td><td>".$row['product_qua']."</td><td>".$row['product_price']."</td> 

	<td><input type='button' onclick='deleteorder(".$row['order_id'].");' value='Delete Order' ></td>


	 </tr>";
	}
    }
	
?>